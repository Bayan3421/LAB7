import pandas as pd
import dask.dataframe as dd
import os

# Установите основной путь к вашим данным
base_path = r'C:\Users\asilb\Desktop\LAB723'
# Папка для сохранения всех Excel файлов
excel_save_path = os.path.join(base_path, 'ALL_DATA')

# Создаем папку, если её не существует
if not os.path.exists(excel_save_path):
    os.makedirs(excel_save_path)

# Список стран и лет
countries = ['Kazakhstan', 'Uzbekistan', 'Tajikistan', 'Kyrgyzstan']
years = ['2014', '2015', '2016', '2017']

# Проходим по каждой стране и каждому году
for country in countries:
    # Создаем список для хранения DataFrame для каждого года
    data_frames = []
    
    for year in years:
        # Читаем данные из .dta и .sav файлов
        dta_path = os.path.join(base_path, country, year, f'{country}_{year}.dta')
        sav_path = os.path.join(base_path, country, year, f'{country}_{year}.sav')

        try:
            # Загружаем данные с использованием Dask для .dta
            data_dta = dd.read_stata(dta_path)

            # Загружаем данные с использованием pandas для .sav
            data_sav = pd.read_spss(sav_path)

            # Обрабатываем данные из .sav
            data_sav['N_child'] = data_sav['N_child'].fillna(0)
            data_sav['children_weight'] = (data_sav['wt'] / data_sav['N_adults']) * data_sav['N_child']
            data_sav['Country'] = country  # Добавляем столбец страны

            # Преобразуем pandas DataFrame в Dask DataFrame
            data_sav_dask = dd.from_pandas(data_sav, npartitions=1)

            # Объединяем данные
            combined_data = dd.concat([data_dta, data_sav_dask])
            data_frames.append(combined_data)

        except FileNotFoundError:
            print(f"Файл не найден для {country} {year}. Проверьте путь.")
        except Exception as e:
            print(f"Ошибка при обработке {country} {year}: {e}")

    # Объединяем все DataFrame в один
    if data_frames:
        final_data = dd.concat(data_frames)
        
        # Сохраняем в Excel файл
        excel_file_path = os.path.join(excel_save_path, f'{country}.xlsx')
        
        # Записываем данные в Excel с несколькими листами
        with pd.ExcelWriter(excel_file_path) as writer:
            for i, year in enumerate(years):
                year_data = data_frames[i] if i < len(data_frames) else pd.DataFrame()  # Обработаем только существующие данные
                year_data.to_excel(writer, sheet_name=year, index=False)

print("Обработка завершена. Данные сохранены в папку ALL_DATA.")














